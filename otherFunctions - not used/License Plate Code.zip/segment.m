function [ parts ] = segment( image, mask )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
                    stats = regionprops(~mask);
                    j =0;
                    disp(length(stats));
                    for index=1:length(stats)
                        if stats(index).Area > 200 && stats(index).BoundingBox(3)*stats(index).BoundingBox(4) < 30000
                            j = j+1;
                            x = ceil(stats(index).BoundingBox(1))
                            y= ceil(stats(index).BoundingBox(2))
                            widthX = floor(stats(index).BoundingBox(3)-1)
                            widthY = floor(stats(index).BoundingBox(4)-1)
                            t = image(y:y+widthY,x:x+widthX,:);
                            parts{j} = t;
                        end
                    end


end

