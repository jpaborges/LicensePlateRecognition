function out = PlateLocalization(input,method,t)
%This function aims to isolate the plate region in the image.
%It can receive as input a cell containing a set of images or only one
%image. Method = 1 (default) is based on smearing, Method = 2 is based on
%boundary analyses.
if (nargin < 3)
    t = .5;
end

if (nargin < 2)
    method = 4;
end

if (~iscell(input))
    
    img = cell(1,1);
    img{1} = input;
else
    img = input;
end
    
    out = cell(1,length(img));
    for k=1:length(img)       
        if (method ==4) %other method
            disp(k);

%             % apply morphological operation and find the plate region
%             mor_img = bwmorph(plate_area,'dilate');
%             label_img = bwlabel(mor_img,4);
%             tot_label = max(max(label_img));
%             plate_area = zeros(size(mor_img,1),size(mor_img,2));
%             plate_region = zeros(size(mor_img,1),size(mor_img,2));
%             for i = 1:tot_label
%                 [r c] = find(label_img==i);
%                 tot = length(r);
%                 if tot>1000
%                     for j = 1:length(r)
%                         plate_area(r(j),c(j)) = 1;
%                     end
%                 end
%             end
%             imshow(plate_area);
%             hori_thresh = sum(plate_area,1);
%             
%             finx = find(hori_thresh~=0);
%             hor_start = finx(1);
%             hor_end = finx(end);
%             ver_thresh = sum(plate_area,2);
%             finx = find(ver_thresh~=0);
%             ver_start = finx(1);
%             ver_end = finx(end);
%             plate_region(ver_start:ver_end,hor_start:hor_end) = bw_img(ver_start:ver_end,hor_start:hor_end);
%             figure;imshow(plate_area);
% 
%             % Plate extraction...
%             detect_plate = bw_img(ver_start+7:ver_end-3,hor_start+4:hor_end-5);
%             u = detect_plate;
        else
            %smearing
            mask = im2bw(img{k},t*graythresh(img{k}));
            if (method ==1 || method == 3) % horizontal smearing
                hori_thresh = sum(mask,2);
                h_finx = find(hori_thresh>=500)
                mask(h_finx,:) = 0;
            end
            if (method == 2 || method == 3) % vertical smearing
                ver_thresh = sum(mask,1);
                v_finx = find(ver_thresh<30);
                mask(:,v_finx) = 0;
            end
            
            
            if (length(size(img{k})) == 3) %color img
                masked = zeros(size(img{k}));
                masked(:,:,1) = img{k}(:,:,1) .* uint8(mask);
                masked(:,:,2) = img{k}(:,:,1) .* uint8(mask);
                masked(:,:,3) = img{k}(:,:,1) .* uint8(mask);
            
            else %grayscale
                masked = img{k} .* uint8(mask);
            end
            
            figure, imshow(masked)
            out{k} = mask;
                   
        end
 
        


        
        
        
    end


end




